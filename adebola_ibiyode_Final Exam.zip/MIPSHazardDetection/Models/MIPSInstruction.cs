﻿namespace MIPSHazardDetection.Models
{
    public class MIPSInstruction
    {
        public string? Opcode { get; set; }
        public string? DestinationRegister { get; set; }
        public string? SourceRegister1 { get; set; }
        public string? SourceRegister2 { get; set; }
        public string? DataHazard { get; set;}
        public string? ControlHazard { get; set; }
        public string? StructuralHazard { get; set; }
    }

    public class MIPSInstructions
    {
        public List<MIPSInstruction>? Instructions { get;set; }
        public string? MIPSComment { get; set; }
        public List<string>? TimingSequence { get; set;}
        public List<string>? TimingSequenceforwarding { get; set; }
    }
}
