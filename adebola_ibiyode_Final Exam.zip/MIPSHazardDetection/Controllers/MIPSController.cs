﻿using Microsoft.AspNetCore.Mvc;
using MIPSHazardDetection.Models;

namespace MIPSHazardDetection.Controllers
{
    public class MIPSController : Controller
    { 
       private static readonly List<MIPSInstruction> MIPSInstructions = new List<MIPSInstruction>();
       private static  MIPSInstructions mIPS = new MIPSInstructions();

        public IActionResult Instructions()
        {
            
            ViewBag.MIPSInstructions = mIPS;
            return View();
        }

        [HttpPost]
        public IActionResult Create(MIPSInstruction instruction)
        {
            
            if (mIPS == null)
            {
                mIPS = new MIPSInstructions(); // assuming MIPS is the type of mIPS
            }

            if (mIPS.Instructions == null)
            {
                mIPS.Instructions = new List<MIPSInstruction>();
            }

            mIPS.Instructions.Add(instruction);
            return RedirectToAction(nameof(Instructions));
        }
        public IActionResult Reset()
        {
            mIPS = new MIPSInstructions();
            mIPS.Instructions = new List<MIPSInstruction>();
            // Redirect to the Create action to refresh the page.
            return RedirectToAction(nameof(Instructions));
        }
        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.MIPSInstructions = mIPS;
            return View();
        }

        [HttpPost]
        public IActionResult HazardCheck()
        {
            ViewBag.MIPSInstructions = mIPS;
           
            DataHazard(mIPS);
            StructuralHazard(mIPS);
            ControlHazard(mIPS);

            PrintTimingSequence(mIPS);
            return RedirectToAction(nameof(Instructions));
        }

        private MIPSInstructions DataHazard(MIPSInstructions instructions)
        {
            if (mIPS == null)
            {
                mIPS = new MIPSInstructions(); // assuming MIPS is the type of mIPS

                RedirectToAction(nameof(Instructions));
            }
            if (mIPS.Instructions == null)
            {
                mIPS.Instructions = new List<MIPSInstruction>();
                RedirectToAction(nameof(Instructions));
            }
            if (instructions != null)
            {              

                for (var i = 0; i < mIPS.Instructions.Count; i++)
                {
                    for (var j = i + 1; j < mIPS.Instructions.Count; j++)
                    {
                        // RAW hazard check: instruction j reads from a register written by instruction i
                        if (mIPS.Instructions[i].DestinationRegister == mIPS.Instructions[j].SourceRegister1 || mIPS.Instructions[i].DestinationRegister == mIPS.Instructions[j].SourceRegister2)
                        {
                            mIPS.Instructions[j].DataHazard = "Potential RAW";
                        }
                        // WAW hazard check: instruction j writes from a register written by instruction i
                        if (mIPS.Instructions[i].DestinationRegister ==  mIPS.Instructions[j].DestinationRegister)
                        {
                            mIPS.Instructions[j].DataHazard = "Potential WAW";
                        }
                        // WAR hazard check: instruction j writes from a register read by instruction i
                        if (mIPS.Instructions[i].SourceRegister1 == mIPS.Instructions[j].DestinationRegister || mIPS.Instructions[i].SourceRegister2 == mIPS.Instructions[j].DestinationRegister)
                        {
                            mIPS.Instructions[j].DataHazard = "Potential WAR";
                        }
                    }
                }
                instructions.MIPSComment = "Data Hazard Check;";
            }
            return instructions;
        }

        private MIPSInstructions ControlHazard(MIPSInstructions instructions)
        {
            if (mIPS == null)
            {
                mIPS = new MIPSInstructions(); // assuming MIPS is the type of mIPS

                RedirectToAction(nameof(Instructions));
            }
            if (mIPS.Instructions == null)
            {
                mIPS.Instructions = new List<MIPSInstruction>();
                RedirectToAction(nameof(Instructions));
            }
            if (instructions != null)
            {
                // List of all branch operations in MIPS
                var branchOperations = new List<string> { "beq", "bne", "jump" };

                // If any instruction is a branch operation, a control hazard could potentially occur
                bool checkhazard = mIPS.Instructions.Any(instr => branchOperations.Contains(instr.Opcode.ToLower()));


                if (checkhazard)
                {
                    foreach (var instr in mIPS.Instructions)
                    {
                        if (branchOperations.Contains(instr.Opcode.ToLower()))
                        {
                            instr.StructuralHazard = "Potential Control Hazard";
                        }
                    }
                }
                instructions.MIPSComment += "Control Hazard Check;";
            }
            return instructions;
        }
        private MIPSInstructions StructuralHazard(MIPSInstructions instructions)
        {
            if (mIPS == null)
            {
                mIPS = new MIPSInstructions(); // assuming MIPS is the type of mIPS

                RedirectToAction(nameof(Instructions));
            }
            if (mIPS.Instructions == null)
            {
                mIPS.Instructions = new List<MIPSInstruction>();
                RedirectToAction(nameof(Instructions));
            }
            if (instructions != null)
            {
                int instructionCount = mIPS.Instructions.Count;

                // If there are more than one memory operation in the sequence, a structural hazard exists.
                bool checkhazard = mIPS.Instructions.Count(instr => instr.Opcode.ToLower() == "lw" || instr.Opcode.ToLower() == "sw") > 1;
                if (checkhazard)
                {
                    foreach(var instr in mIPS.Instructions)
                    {
                        if(instr.Opcode.ToLower() == "lw" || instr.Opcode.ToLower() == "sw")
                        {
                            instr.StructuralHazard = "Potential Structural Hazard";                            
                        }
                    }
                }
                instructions.MIPSComment += "Structural Hazard Check;";

            }
            return instructions;
        }

        public void PrintTimingSequence(MIPSInstructions instructions)
        {
            var pipelineStages = new[] { "F", "D", "X", "M", "W" };

            if (mIPS == null)
            {
                mIPS = new MIPSInstructions(); // assuming MIPS is the type of mIPS

                RedirectToAction(nameof(Instructions));
            }
            if (mIPS.Instructions == null)
            {
                mIPS.Instructions = new List<MIPSInstruction>();
                RedirectToAction(nameof(Instructions));
            }
            if (mIPS.TimingSequence == null)
            {
                mIPS.TimingSequence = new List<String>();
                RedirectToAction(nameof(Instructions));
            }
            if (mIPS.TimingSequenceforwarding == null)
            {
                mIPS.TimingSequenceforwarding = new List<String>();
                RedirectToAction(nameof(Instructions));
            }
            if (instructions != null)
            {
                int totalCycles = mIPS.Instructions.Count + pipelineStages.Length - 1;          

                int numStall = 0;
                //No forwarding unit
                for (int i = 0; i < mIPS.Instructions.Count; i++)
                {
                    string ts = "";

                    int timestart = i + numStall;
                    numStall = 0;
                    for (int k = 0; k <= timestart; k++)
                    {
                        ts = ts + "  ";
                    }
                    // Forwarding Unit Disabled
                    bool isStalled = false;
                    for (int j = 0; j < pipelineStages.Length; j++)
                    {                        
                        if (j < 1)
                        {
                            ts = ts + pipelineStages[j] + " ";
                        }
                        if (j >= 1)
                        {                            
                            if ((i > 0 && !isStalled) && (mIPS.Instructions[i].DataHazard != null || mIPS.Instructions[i].ControlHazard != null || mIPS.Instructions[i].StructuralHazard != null))
                            {
                                ts = ts + "S S " + pipelineStages[j] + " ";
                                isStalled = true;
                                numStall +=2;
                            }
                            else
                            {
                                ts = ts + pipelineStages[j] + " ";
                            }
                        }                        
                    }
                    ts = ts + "\r";
                    instructions.TimingSequence.Add(ts);

                }

                //Forwarding Unit
                for(int i = 0; i < mIPS.Instructions.Count; i++)
                {
                    string ts = "";

                    int timestart = i + numStall;
                    numStall = 0;
                    for (int k = 0; k <= timestart; k++)
                    {
                        ts = ts + "  ";
                    }
                    // Forwarding Unit Disabled
                    bool isStalled = false;
                    for (int j = 0; j < pipelineStages.Length; j++)
                    {
                        if (j <= 1)
                        {
                            ts = ts + pipelineStages[j] + " ";
                        }
                        if (j > 1)
                        {
                            if ((i > 0 && !isStalled) && (mIPS.Instructions[i].DataHazard != null || mIPS.Instructions[i].ControlHazard != null) && (mIPS.Instructions[i - 1].StructuralHazard != null))
                            {
                                ts = ts + "S " + pipelineStages[j] + " ";
                                isStalled = true;
                                numStall += 2;
                            }
                            else if ((i > 0 && !isStalled) && (mIPS.Instructions[i].DataHazard != null || mIPS.Instructions[i].ControlHazard != null) && (mIPS.Instructions[i].StructuralHazard != null))
                            {
                                ts = ts + "S " + pipelineStages[j] + " ";
                                isStalled = true;
                                numStall += 2;
                            }
                            else
                            {
                                ts = ts + pipelineStages[j] + " ";
                            }
                        }
                    }
                    ts = ts + "\r";
                    instructions.TimingSequenceforwarding.Add(ts);

                }
            }
        }
    }
}
